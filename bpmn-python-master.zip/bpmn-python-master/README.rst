bpmn-python
===========

Project for creating a Python library that allows to import/export BPMN
diagram (as an XML file) and provides a simple visualization
capabilities

Project structure \* bpmn\_python - main module of project, includes all
source code \* tests - unit tests for package \* examples - examples of
XML files used in tests \* docs - documentation for package
