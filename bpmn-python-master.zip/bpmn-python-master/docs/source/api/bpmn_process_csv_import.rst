BPMN process CSV import
=======================

.. automodule:: bpmn_python.bpmn_process_csv_import
.. autoclass:: BpmnDiagramGraphCSVImport
    :members:
