BPMN diagram representation
===========================

.. automodule:: bpmn_python.bpmn_diagram_rep
.. autoclass:: BpmnDiagramGraph
    :members:
