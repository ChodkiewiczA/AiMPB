BPMN diagram metrics
====================

.. automodule:: bpmn_python.bpmn_diagram_metrics
    :members:
