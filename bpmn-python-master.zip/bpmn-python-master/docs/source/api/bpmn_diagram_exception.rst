BPMN digram exceptions
======================

.. automodule:: bpmn_python.bpmn_diagram_exception
.. autoclass:: BpmnPythonError
    :members:
